export interface ProductCompleteResponse {
    id : number
    title : string
    price: string
    description : string
    thumbnail : string
    images: []
    reviws: object[]
}