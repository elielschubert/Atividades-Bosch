export interface LoginResponse {
    email :  string
    firstName : string
    lastName : string
    image : string  
}
