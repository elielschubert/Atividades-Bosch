export interface ProductResponse {
    title : string
    thumbnail : string
    price: string
    id : number
}
